import React from "react";

const Body = () =>{
    return (
        <p>Body</p>
    )
}

export default Body;